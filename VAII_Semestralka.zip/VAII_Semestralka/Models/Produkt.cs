﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VAII_Semestralka.Models
{
    public class Produkt
    {
        [Key]
        public int Id { get; set; }

        public string Typ { get; set; }
        public string Opis { get; set; }
        public string Obrazok { get; set; }
        public string MaterialID { get; set; }

    }
}
