﻿using System.Runtime.CompilerServices;
using Microsoft.AspNetCore.Mvc;
using VAII_Semestralka.Data;
using VAII_Semestralka.Models;

namespace VAII_Semestralka.Controllers
{
    public class ProduktController : Controller
    {

        private readonly AppDbContext _context;

        public ProduktController(AppDbContext context)
        {
            _context = context;
        }

        public IActionResult Produkty()
        {
            var produkty = _context.Produkty.ToList();
            return View(produkty);
        }

        [HttpGet]
        public IActionResult Vytvor()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Vytvor(Produkt produkt)
        {
	        if (ModelState.IsValid)
	        {
		        return View(produkt);
	        }

	        _context.Produkty.Add(produkt);
	        return RedirectToAction("Produkty");
        }
		[HttpPost]
		public IActionResult Vymaz(int id)
		{
			 var produkt = _context.Produkty.FirstOrDefault(p => p.Id == id);

			 if (produkt == null)
			 {
			     return NotFound();
			 }

			 _context.Produkty.Remove(produkt);
			 _context.SaveChanges();

			return RedirectToAction("Produkty");
		}

		[HttpGet]
		[Route("Produkty/{id}")]
		public IActionResult Najdi(int id)
		{
			var produkt = _context.Produkty.FirstOrDefault(p => p.Id == id);
			if (produkt == null)
			{
				return RedirectToAction("Produkty");
			}

			return Redirect("Produkty/"+produkt.Obrazok);

		}

		[HttpGet]
		public IActionResult Uprav(int id)
		{
			var produkt = _context.Produkty.FirstOrDefault(p => p.Id == id);
			if (produkt == null) return NotFound();
			var produktModel = new Produkt
			{
				Typ = produkt.Typ,
				Opis = produkt.Opis,
				Obrazok = produkt.Obrazok,
				MaterialID = produkt.MaterialID,

			};
			return View(produktModel);
		}

    }
}
